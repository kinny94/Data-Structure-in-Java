Please refer to the entire program if there is an issue in running the function.
Implementation - 
This program consists of basic mathmatics. All conversion is done using normal base conversion mathmatics. I have created one if-else statement, to sparate the hexadecimal conversion from other conversions, because hexadecimal conversions include Alphabetical characters also. 
This program roughly took me an hour. 